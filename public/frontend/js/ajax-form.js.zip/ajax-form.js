$(function () {
    var form = $('#contact-form');
    var formMessages = $('.ajax-response');
    $(form).submit(function (e) {
        e.preventDefault();
        var formData = $(form).serialize();
        $.ajax({type: 'POST', url: $(form).attr('action'), data: formData}).done(function (response) {
            $(formMessages).removeClass('error');
            $(formMessages).addClass('success');
            $(formMessages).text(response);
            $('#contact-form input,#contact-form textarea').val('');
        }).fail(function (data) {
            $(formMessages).removeClass('success');
            $(formMessages).addClass('error');
            if (data.responseText !== '') {
                $(formMessages).text(data.responseText);
            } else {
                $(formMessages).text('Oops! An error occurred and your message could not be sent.');
            }
        });
    });
    var OrderIDForm = $('#Order-Track');
    var OrderIDFormMessages = $('.order-id-form-messages');
    $(OrderIDForm).submit(function (e) {
        e.preventDefault();
        var formData = $(OrderIDForm).serialize();
        $.ajax({type: 'POST', url: $(OrderIDForm).attr('action'), data: formData}).done(function (response) {
            $(OrderIDFormMessages).removeClass('error');
            $(OrderIDFormMessages).addClass('success');
            $(OrderIDFormMessages).text(response);
            $('#contact-form input,#contact-form textarea').val('');
        }).fail(function (data) {
            $(OrderIDFormMessages).removeClass('success');
            $(OrderIDFormMessages).addClass('error');
            if (data.responseText !== '') {
                $(OrderIDFormMessages).text(data.responseText);
            } else {
                $(OrderIDFormMessages).text('Oops! An error occurred and your message could not be sent.');
            }
        });
    });
    var IntantQuoteForm = $('#Instant-Quote-Form');
    var IntantQuoteFormMessages = $('.instant-quote-form-messages');
    $(IntantQuoteForm).submit(function (e) {
        e.preventDefault();
        var formData = $(IntantQuoteForm).serialize();
        $.ajax({type: 'POST', url: $(IntantQuoteForm).attr('action'), data: formData}).done(function (response) {
            $(IntantQuoteFormMessages).removeClass('error');
            $(IntantQuoteFormMessages).addClass('success');
            $(IntantQuoteFormMessages).text(response);
            $('#contact-form input,#contact-form textarea').val('');
        }).fail(function (data) {
            $(IntantQuoteFormMessages).removeClass('success');
            $(IntantQuoteFormMessages).addClass('error');
            if (data.responseText !== '') {
                $(IntantQuoteFormMessages).text(data.responseText);
            } else {
                $(IntantQuoteFormMessages).text('Oops! An error occurred and your message could not be sent.');
            }
        });
    });
});
